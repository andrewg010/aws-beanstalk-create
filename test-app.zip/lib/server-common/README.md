# server-common

The project contains code that is used by more than one server side application.

## Setting up in your project

Simply add it to your `package.json` file using the git approach.

```"server-common": "git+https://ceRead:Db9DwnzWJvNkPtX9@bitbucket.org/climateedge/server-common.git#v0.1.8"```
