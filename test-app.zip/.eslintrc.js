module.exports = {
	"extends": "eslint-config-ce"
};
