module.exports = {

	/**
	 * Just a method to write a test suite for
	 * @param value
	 * @returns {*|string}
	 */
	testUtil: (value) => value || 'undefined'
};
